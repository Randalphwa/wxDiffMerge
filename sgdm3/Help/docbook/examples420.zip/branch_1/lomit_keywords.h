this
is
a
test
of
the
Hello $Revision: 47 $ There.
Goodbye $Date: $ There.
emergency
broadcasting
system.

This
is
only
a
test.
