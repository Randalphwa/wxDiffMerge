a important identical
b // unimportant identical
IMPORTANT Non-Matching change
// UNIMPORTANT Non-Matching change
identical line
conflict AAAA // aaaa
IMPORTANT Non-Matching change
// UNIMPORTANT Non-Matching change
