// AboutBox.cpp
//////////////////////////////////////////////////////////////////

Line 1

#include <ConfigPch.h>
#include <ConfigDcl.h>
#include <util.h>
#include <rs.h>
#include <fim.h>
#include <poi.h>
#include <fs.h>
#include <fd.h>
#include <gui.h>

//////////////////////////////////////////////////////////////////

#define M 7
#define FIX 0
#define VAR 1

//////////////////////////////////////////////////////////////////

BEGIN_EVENT_TABLE(AboutBox,wxDialog)
	EVT_BUTTON(ID_BUTTON_SUPPORT,		AboutBox::onEventButton_Support)
END_EVENT_TABLE()

//////////////////////////////////////////////////////////////////

AboutBox::AboutBox(gui_frame * pFrame)
	: wxDialog(pFrame,-1,VER_ABOUTBOX_TITLE,
			   wxDefaultPosition,wxDefaultSize,
			   wxDEFAULT_DIALOG_STYLE),
	  m_pFrame(pFrame)
{
	wxBoxSizer * vSizerTop = new wxBoxSizer(wxVERTICAL);
	{
		wxBoxSizer * hSizerField = new wxBoxSizer(wxHORIZONTAL);
		{
			hSizerField->Add( new wxStaticBitmap(this,wxID_ANY,wxBitmap(DiffMergeIcon_xpm)), FIX, wxALL | wxALIGN_LEFT, M);
			wxBoxSizer * vSizerText = new wxBoxSizer(wxVERTICAL);
			{
				wxString strBuildVersion = build_version_string();
				
				vSizerText->Add( new wxStaticText(this,wxID_ANY, VER_APP_TITLE),   FIX, wxALL, M);
				vSizerText->Add( new wxStaticText(this,wxID_ANY, strBuildVersion), FIX, wxALL, M);
				vSizerText->Add( new wxStaticText(this,wxID_ANY, VER_COPYRIGHT),   FIX, wxALL, M);
				vSizerText->Add( new wxStaticText(this,wxID_ANY, VER_COMPANY_URL), FIX, wxALL, M);
			}
			hSizerField->Add(vSizerText,FIX, wxALL,M);
		}
		vSizerTop->Add(hSizerField,FIX,0,0);

		// put horizontal line and set of ok/cancel buttons across the bottom of the dialog

		vSizerTop->AddStretchSpacer(VAR);
		vSizerTop->Add( new wxStaticLine(this,wxID_ANY,wxDefaultPosition,wxDefaultSize,wxLI_HORIZONTAL), FIX, wxGROW| wxLEFT|wxRIGHT, M);
		wxBoxSizer * hSizerButtonBar = new wxBoxSizer(wxHORIZONTAL);
		{
			hSizerButtonBar->Add( new wxButton(this,ID_BUTTON_SUPPORT,_("&Support...")), FIX, 0,0);
			hSizerButtonBar->AddStretchSpacer(VAR);
			hSizerButtonBar->Add( new wxButton(this,wxID_CANCEL,_("&Close")), FIX, 0,0);	// using wxID_CANCEL lets ESC key close dialog
		}
		vSizerTop->Add(hSizerButtonBar,FIX,wxGROW|wxALL,M);
		
	}
	SetSizer(vSizerTop);
	vSizerTop->SetSizeHints(this);
	vSizerTop->Fit(this);
	Centre(wxBOTH);
}

//////////////////////////////////////////////////////////////////

/*static*/wxString AboutBox::build_version_string(void)
{
	wxString strBuildLabel(VER_BUILD_LABEL);
	if (strBuildLabel.StartsWith(_T("@")))			// if optional BUILDLABEL was NOT set by script running the compiler
		strBuildLabel = _T("");						// then we don't want to include it in the version number line.
				
	wxString strVersion = wxString::Format(_("Version %d.%d.%d (%d) %s"),
										   VER_MAJOR_VERSION,VER_MINOR_VERSION,VER_MINOR_SUBVERSION,VER_BUILD_NUMBER,strBuildLabel.c_str());

	return strVersion;
}

//////////////////////////////////////////////////////////////////

void AboutBox::onEventButton_Support(wxCommandEvent & /*e*/)
{
	SupportDlg dlg(this,m_pFrame);
	dlg.ShowModal();
}
