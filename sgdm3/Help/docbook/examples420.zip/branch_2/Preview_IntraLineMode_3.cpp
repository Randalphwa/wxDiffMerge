A important identical
B // unimportant identical
important Matching change
// unimportant Matching change
identical line
conflict CCCC // cccc
important Matching change
// unimportant Matching change
