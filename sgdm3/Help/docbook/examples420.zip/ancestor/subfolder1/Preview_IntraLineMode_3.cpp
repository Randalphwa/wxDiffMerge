A important identical
B // unimportant identical
important Matching change
// unimportant Matching change
identical line
conflict BBBB // bbbb
important Matching change
// unimportant Matching change
