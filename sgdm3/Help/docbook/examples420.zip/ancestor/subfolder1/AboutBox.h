// AboutBox.h
// About Box dialog.
//////////////////////////////////////////////////////////////////

#ifndef H_ABOUTBOX_H
#define H_ABOUTBOX_H

//////////////////////////////////////////////////////////////////

class AboutBox : public wxDialog
{
public:
	AboutBox(gui_frame * pFrame);

	static wxString	build_version_string(void);


	typedef enum {	ID_BUTTON_SUPPORT = 100,
	} ID;

	DECLARE_EVENT_TABLE();

public:
	void			onEventButton_Support(wxCommandEvent & e);

private:
	gui_frame *		m_pFrame;
};

//////////////////////////////////////////////////////////////////

#endif//H_ABOUTBOX_H
