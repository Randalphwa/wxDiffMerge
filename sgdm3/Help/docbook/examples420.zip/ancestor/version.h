// version.h
//////////////////////////////////////////////////////////////////

#ifndef H_VERSION_H
#define H_VERSION_H

//////////////////////////////////////////////////////////////////
// The following strange macros are for the build server.  The
// buildserver will change the "//BUILDSERVER" to "#define BUILDSERVER"
// and replace each of the @TOKEN@ with proper values.
// Normal debug/developer builds get other values.

//BUILDSERVER

#ifdef BUILDSERVER
#	define VER_MAJOR_VERSION			@MAJOR@
#	define VER_MAJOR_VERSION_STR		"@MAJOR@"

#	define VER_MINOR_VERSION			@MINOR@
#	define VER_MINOR_VERSION_STR		"@MINOR@"

#	define VER_MINOR_SUBVERSION			@REVISION@
#	define VER_MINOR_SUBVERSION_STR		"@REVISION@"

#	define VER_BUILD_NUMBER				@BUILDNUM@
#	define VER_BUILD_NUMBER_STR			"@BUILDNUM@"

#	define VER_COPYRIGHT				_T("Copyright (C) @COPYRIGHTDATE@ SourceGear LLC. All Rights Reserved.")
#	define VER_COPYRIGHT_RC_STR			"Copyright (C) @COPYRIGHTDATE@ SourceGear LLC. All Rights Reserved."

#	define VER_BUILD_LABEL				_T("@BUILDLABEL@")

#else

#	define VER_MAJOR_VERSION			3
#	define VER_MAJOR_VERSION_STR		"3"

#	define VER_MINOR_VERSION			0
#	define VER_MINOR_VERSION_STR		"0"

#	define VER_MINOR_SUBVERSION			0
#	define VER_MINOR_SUBVERSION_STR		"0"

#	define VER_BUILD_NUMBER				0
#	define VER_BUILD_NUMBER_STR			"0"

#	define VER_COPYRIGHT				_T("Copyright (C) 2003-2007 SourceGear LLC. All Rights Reserved.")
#	define VER_COPYRIGHT_RC_STR			"Copyright (C) 2003-2007 SourceGear LLC. All Rights Reserved."

#	if 1
#		define VER_BUILD_LABEL			_T("[Beta 1.1]")
#	else
#		define VER_BUILD_LABEL			_T("[DEV]")
#	endif

#endif

//////////////////////////////////////////////////////////////////

#define VER_REG_VENDOR		_T("SourceGear")
#define VER_REG_APP_NAME	_T("DiffMerge Tool")

#define VER_APP_NAME		_T("sgdm3")
#define VER_APP_TITLE		_T("SourceGear DiffMerge")
#define VER_APP_TITLE_s		_T("%s - SourceGear DiffMerge")
#define VER_COMPANY			_T("SourceGear LLC")

#define VER_COMPANY_URL		_T("www.sourcegear.com")
#define VER_ABOUTBOX_TITLE	_T("About SourceGear DiffMerge")

//////////////////////////////////////////////////////////////////

#endif//H_VERSION_H
